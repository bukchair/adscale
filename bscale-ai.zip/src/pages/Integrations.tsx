import React, { useState } from 'react';
import { Plug, CheckCircle2, ShoppingCart, BarChart2, Mail, Search, Megaphone, Video, Facebook, AlertCircle, Loader2, X, Store, HelpCircle, ChevronDown, ChevronUp, Sparkles, Settings2, Key, Link as LinkIcon, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { useConnections, Connection } from '../contexts/ConnectionsContext';

const iconMap: Record<string, React.ElementType> = {
  'gemini': Sparkles,
  'google': Megaphone,
  'meta': Facebook,
  'tiktok': Video,
  'woocommerce': ShoppingCart,
  'shopify': Store,
};

const brandStyles: Record<string, { bg: string, text: string, border: string, lightBg: string }> = {
  'gemini': { bg: 'bg-gradient-to-br from-purple-500 to-blue-500', text: 'text-white', border: 'border-purple-200', lightBg: 'bg-purple-50' },
  'google': { bg: 'bg-gradient-to-br from-blue-500 to-red-400', text: 'text-white', border: 'border-blue-200', lightBg: 'bg-blue-50' },
  'meta': { bg: 'bg-gradient-to-br from-blue-600 to-blue-700', text: 'text-white', border: 'border-blue-200', lightBg: 'bg-blue-50' },
  'tiktok': { bg: 'bg-gradient-to-br from-gray-800 to-black', text: 'text-white', border: 'border-gray-300', lightBg: 'bg-gray-100' },
  'woocommerce': { bg: 'bg-gradient-to-br from-purple-600 to-purple-800', text: 'text-white', border: 'border-purple-200', lightBg: 'bg-purple-50' },
  'shopify': { bg: 'bg-gradient-to-br from-emerald-500 to-green-600', text: 'text-white', border: 'border-emerald-200', lightBg: 'bg-emerald-50' },
};

export function Integrations() {
  const { connections, toggleConnection, updateConnectionSettings } = useConnections();
  const [error, setError] = useState<{ id: string; message: string } | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [formValues, setFormValues] = useState<Record<string, string>>({});

  const handleExpand = (integration: Connection) => {
    if (expandedId === integration.id) {
      setExpandedId(null);
    } else {
      setExpandedId(integration.id);
      setFormValues(integration.settings || {});
    }
  };

  const handleInputChange = (key: string, value: string) => {
    setFormValues(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async (id: string) => {
    setError(null);
    try {
      await updateConnectionSettings(id, formValues);
      setExpandedId(null);
    } catch (err) {
      setError({ id, message: 'אירעה שגיאה לא צפויה במהלך שמירת ההגדרות.' });
    }
  };

  const handleToggle = async (id: string, subId?: string) => {
    setError(null);
    try {
      await toggleConnection(id, subId);
    } catch (err) {
      setError({ id, message: 'אירעה שגיאה לא צפויה במהלך ההתחברות.' });
    }
  };

  const renderIntegrationSettings = (integration: Connection) => {
    const isConnected = integration.status === 'connected';
    const isConnecting = integration.status === 'connecting';

    return (
      <motion.div 
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        className="overflow-hidden"
      >
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <Settings2 className="w-4 h-4 text-gray-400" />
              הגדרות חיבור - {integration.name}
            </h4>
            <button 
              onClick={() => setExpandedId(null)}
              className="text-gray-400 hover:text-gray-600 transition-colors bg-gray-50 hover:bg-gray-100 p-2 rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3 space-y-5">
            {/* Dynamic Form Fields based on Integration ID */}
            {integration.id === 'gemini' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">API Key</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Key className="h-4 w-4 text-gray-400" />
                    </div>
                    <input type="password" placeholder="AIzaSy..." className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.apiKey || (isConnected ? "••••••••••••••••" : "")} onChange={(e) => handleInputChange('apiKey', e.target.value)} />
                  </div>
                  <p className="text-xs text-gray-500 mt-1.5">המפתח מ-Google AI Studio</p>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">מודל ברירת מחדל</label>
                  <select className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white" value={formValues.model || "Gemini 1.5 Pro (מומלץ)"} onChange={(e) => handleInputChange('model', e.target.value)}>
                    <option>Gemini 1.5 Pro (מומלץ)</option>
                    <option>Gemini 1.5 Flash (מהיר)</option>
                  </select>
                </div>
              </div>
            )}

            {integration.id === 'google' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Google Ads Account ID</label>
                  <input type="text" placeholder="123-456-7890" className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.adsId || (isConnected ? "987-654-3210" : "")} onChange={(e) => handleInputChange('adsId', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">GA4 Measurement ID</label>
                  <input type="text" placeholder="G-XXXXXXXXXX" className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.ga4Id || (isConnected ? "G-A1B2C3D4E5" : "")} onChange={(e) => handleInputChange('ga4Id', e.target.value)} />
                </div>
              </div>
            )}

            {integration.id === 'meta' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Business Manager ID</label>
                  <input type="text" placeholder="123456789012345" className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.bmId || (isConnected ? "109876543210987" : "")} onChange={(e) => handleInputChange('bmId', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Meta Pixel ID</label>
                  <input type="text" placeholder="987654321098765" className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.pixelId || (isConnected ? "567890123456789" : "")} onChange={(e) => handleInputChange('pixelId', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">System User Access Token</label>
                  <input type="password" placeholder="EAAB..." className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.metaToken || (isConnected ? "••••••••••••••••" : "")} onChange={(e) => handleInputChange('metaToken', e.target.value)} />
                </div>
              </div>
            )}

            {integration.id === 'tiktok' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Advertiser ID</label>
                  <input type="text" placeholder="7012345678901234567" className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.tiktokAdvertiserId || (isConnected ? "7123456789012345678" : "")} onChange={(e) => handleInputChange('tiktokAdvertiserId', e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Access Token</label>
                  <input type="password" placeholder="act_..." className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.tiktokToken || (isConnected ? "••••••••••••••••" : "")} onChange={(e) => handleInputChange('tiktokToken', e.target.value)} />
                </div>
              </div>
            )}

            {(integration.id === 'woocommerce' || integration.id === 'shopify') && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">כתובת החנות (URL)</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <LinkIcon className="h-4 w-4 text-gray-400" />
                    </div>
                    <input type="url" placeholder="https://mystore.co.il" className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.storeUrl || (isConnected ? "https://mystore.co.il" : "")} onChange={(e) => handleInputChange('storeUrl', e.target.value)} />
                  </div>
                </div>
                
                {integration.id === 'woocommerce' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Consumer Key</label>
                      <input type="text" placeholder="ck_..." className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.wooKey || (isConnected ? "ck_1234567890" : "")} onChange={(e) => handleInputChange('wooKey', e.target.value)} />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Consumer Secret</label>
                      <input type="password" placeholder="cs_..." className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.wooSecret || (isConnected ? "••••••••••••••••" : "")} onChange={(e) => handleInputChange('wooSecret', e.target.value)} />
                    </div>
                  </div>
                )}

                {integration.id === 'shopify' && (
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Admin API Access Token</label>
                    <input type="password" placeholder="shpat_..." className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left" dir="ltr" value={formValues.shopifyToken || (isConnected ? "••••••••••••••••" : "")} onChange={(e) => handleInputChange('shopifyToken', e.target.value)} />
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
              {!isConnected ? (
                <button
                  onClick={() => handleSave(integration.id)}
                  disabled={isConnecting}
                  className="flex-1 bg-indigo-600 text-white px-3 py-2 rounded-lg text-xs font-bold hover:bg-indigo-700 transition-all shadow-sm hover:shadow flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isConnecting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plug className="w-3.5 h-3.5" />}
                  שמור והתחבר
                </button>
              ) : (
                <>
                  <button
                    onClick={() => handleSave(integration.id)}
                    disabled={isConnecting}
                    className="flex-1 bg-white border border-gray-200 text-gray-700 px-3 py-2 rounded-lg text-xs font-bold hover:bg-gray-50 transition-all shadow-sm flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isConnecting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                    עדכן הגדרות
                  </button>
                  <button
                    onClick={() => {
                      handleToggle(integration.id);
                      setExpandedId(null);
                    }}
                    disabled={isConnecting}
                    className="px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    נתק
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-indigo-50/50 rounded-2xl p-6 border border-indigo-100/50 h-full">
              <h5 className="font-bold text-indigo-900 mb-4 flex items-center gap-2">
                <div className="bg-indigo-100 text-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-black">i</div>
                איך מתחברים?
              </h5>
              
              <div className="prose prose-sm prose-indigo text-indigo-800/80">
                {integration.id === 'gemini' && (
                  <ol className="space-y-3 list-decimal list-inside marker:text-indigo-400 marker:font-bold">
                    <li>היכנס ל-<a href="https://aistudio.google.com/" target="_blank" rel="noreferrer" className="text-indigo-600 font-bold hover:underline">Google AI Studio</a>.</li>
                    <li>לחץ על <strong>Get API key</strong> בתפריט הצד.</li>
                    <li>צור מפתח חדש (Create API key).</li>
                    <li>העתק את המפתח והדבק אותו בשדה המיועד.</li>
                  </ol>
                )}
                {integration.id === 'google' && (
                  <ol className="space-y-3 list-decimal list-inside marker:text-indigo-400 marker:font-bold">
                    <li>היכנס לחשבון ה-Google Ads שלך והעתק את מזהה הלקוח (10 ספרות) מהפינה העליונה.</li>
                    <li>עבור ל-Google Analytics 4, כנס ל-Admin &gt; Data Streams והעתק את ה-Measurement ID (מתחיל ב-G-).</li>
                    <li>הדבק את הנתונים ולחץ "שמור והתחבר".</li>
                  </ol>
                )}
                {integration.id === 'meta' && (
                  <ol className="space-y-3 list-decimal list-inside marker:text-indigo-400 marker:font-bold">
                    <li>היכנס ל-<strong>Meta Business Settings</strong>.</li>
                    <li>תחת Users, בחר ב-<strong>System Users</strong>.</li>
                    <li>צור משתמש מערכת חדש והקצה לו הרשאות לנכסים (Pixel, Ad Account).</li>
                    <li>לחץ על <strong>Generate New Token</strong> והעתק אותו.</li>
                    <li>העתק את מזהה הפיקסל ומזהה הביזנס מנג'ר.</li>
                  </ol>
                )}
                {integration.id === 'tiktok' && (
                  <ol className="space-y-3 list-decimal list-inside marker:text-indigo-400 marker:font-bold">
                    <li>היכנס ל-<strong>TikTok For Business</strong>.</li>
                    <li>עבור אל Developer Portal וצור אפליקציה חדשה.</li>
                    <li>אשר הרשאות לניהול קמפיינים.</li>
                    <li>העתק את ה-Access Token ואת ה-Advertiser ID והדבק כאן.</li>
                  </ol>
                )}
                {integration.id === 'woocommerce' && (
                  <ol className="space-y-3 list-decimal list-inside marker:text-indigo-400 marker:font-bold">
                    <li>היכנס לפאנל הניהול של WordPress.</li>
                    <li>נווט אל <strong>WooCommerce</strong> &gt; <strong>Settings</strong> &gt; <strong>Advanced</strong> &gt; <strong>REST API</strong>.</li>
                    <li>לחץ על <strong>Add Key</strong>, תן שם והגדר הרשאות ל-<strong>Read/Write</strong>.</li>
                    <li>העתק את ה-Consumer Key וה-Consumer Secret.</li>
                  </ol>
                )}
                {integration.id === 'shopify' && (
                  <ol className="space-y-3 list-decimal list-inside marker:text-indigo-400 marker:font-bold">
                    <li>היכנס לפאנל הניהול של Shopify.</li>
                    <li>נווט אל <strong>Settings</strong> &gt; <strong>Apps and sales channels</strong> &gt; <strong>Develop apps</strong>.</li>
                    <li>צור אפליקציה חדשה והגדר הרשאות קריאה/כתיבה.</li>
                    <li>התקן את האפליקציה והעתק את ה-<strong>Admin API access token</strong>.</li>
                  </ol>
                )}
              </div>
            </div>
          </div>
        </div>
        </div>
      </motion.div>
    );
  };

  const renderConnectionCard = (integration: Connection) => {
    const isConnected = integration.status === 'connected';
    const isConnecting = integration.status === 'connecting';
    const hasError = integration.status === 'error';
    const Icon = iconMap[integration.id] || Plug;
    const isExpanded = expandedId === integration.id;
    const brand = brandStyles[integration.id] || { bg: 'bg-gray-500', text: 'text-white', border: 'border-gray-200', lightBg: 'bg-gray-50' };
    
    return (
      <motion.div 
        layout
        key={integration.id} 
        className={cn(
          "bg-white rounded-2xl border transition-all duration-300 flex flex-col overflow-hidden group relative",
          isConnected ? "border-emerald-200 shadow-sm" : 
          hasError ? "border-red-300 shadow-sm" : "border-gray-200 hover:border-indigo-300 hover:shadow-lg hover:-translate-y-1",
          isExpanded ? "md:col-span-2 lg:col-span-3 ring-2 ring-indigo-500/20 border-indigo-300 shadow-lg" : ""
        )}
      >
        {/* Top Accent Line */}
        <div className={cn("h-1.5 w-full", brand.bg)} />

        <div className="p-4">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
            <div className="flex items-start gap-3 flex-1">
              <div className={cn(
                "flex items-center justify-center w-10 h-10 rounded-xl shrink-0 shadow-sm",
                brand.bg, brand.text
              )}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 pt-0.5">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-base font-bold text-gray-900">{integration.name}</h3>
                  <div className="flex items-center gap-2">
                    {/* Help Bubble Trigger */}
                    <div className="relative group">
                      <button className="text-gray-400 hover:text-indigo-600 transition-colors p-1 rounded-full hover:bg-indigo-50">
                        <HelpCircle className="w-5 h-5" />
                      </button>
                      <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-64 bg-white border border-gray-200 shadow-xl rounded-xl p-4 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-white border-b border-r border-gray-200 transform rotate-45"></div>
                        <h4 className="font-bold text-gray-900 mb-2 text-sm flex items-center gap-2">
                          <HelpCircle className="w-4 h-4 text-indigo-500" />
                          איך מתחברים?
                        </h4>
                        <div className="text-xs text-gray-600 space-y-2">
                          {integration.id === 'gemini' && (
                            <>
                              <p>קבל מפתח API מ-Google AI Studio כדי להפעיל את יכולות ה-AI.</p>
                              <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline font-medium inline-flex items-center gap-1">
                                קבל מפתח כאן <LinkIcon className="w-3 h-3" />
                              </a>
                            </>
                          )}
                          {integration.id === 'google' && (
                            <>
                              <p>חבר את חשבון ה-Google Ads וה-Analytics שלך למעקב מלא.</p>
                              <a href="https://ads.google.com/" target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline font-medium inline-flex items-center gap-1">
                                Google Ads <LinkIcon className="w-3 h-3" />
                              </a>
                            </>
                          )}
                          {integration.id === 'meta' && (
                            <>
                              <p>הפק System User Token מה-Business Manager של Meta.</p>
                              <a href="https://business.facebook.com/settings" target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline font-medium inline-flex items-center gap-1">
                                Business Settings <LinkIcon className="w-3 h-3" />
                              </a>
                            </>
                          )}
                          {integration.id === 'tiktok' && (
                            <>
                              <p>צור אפליקציה ב-Developer Portal כדי לקבל Access Token.</p>
                              <a href="https://ads.tiktok.com/marketing_api/" target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline font-medium inline-flex items-center gap-1">
                                Developer Portal <LinkIcon className="w-3 h-3" />
                              </a>
                            </>
                          )}
                          {integration.id === 'woocommerce' && (
                            <>
                              <p>צור מפתחות REST API דרך הגדרות החנות בוורדפרס.</p>
                              <p className="text-gray-500 italic">Settings &gt; Advanced &gt; REST API</p>
                            </>
                          )}
                          {integration.id === 'shopify' && (
                            <>
                              <p>צור אפליקציה פרטית ב-Shopify כדי לקבל Admin API Token.</p>
                              <p className="text-gray-500 italic">Settings &gt; Apps and sales channels</p>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    {/* Mobile Status Badge */}
                    <div className="md:hidden">
                      {isConnected ? (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="w-3.5 h-3.5 ml-1" /> מחובר
                        </span>
                      ) : isConnecting ? (
                         <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                          <Loader2 className="w-3.5 h-3.5 ml-1 animate-spin" /> מתחבר...
                        </span>
                      ) : hasError ? (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-red-50 text-red-700 border border-red-200">
                          <AlertCircle className="w-3.5 h-3.5 ml-1" /> שגיאה
                        </span>
                      ) : null}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-gray-500 leading-relaxed pr-1 line-clamp-2">{integration.description}</p>
                
                {isConnected && integration.score && (
                  <div className="mt-4 flex items-center gap-3 bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <span className="text-xs font-bold text-gray-600 shrink-0">תקינות חיבור:</span>
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={cn(
                          "h-full rounded-full transition-all duration-1000",
                          integration.score >= 90 ? "bg-emerald-500" :
                          integration.score >= 70 ? "bg-amber-500" :
                          "bg-red-500"
                        )}
                        style={{ width: `${integration.score}%` }}
                      />
                    </div>
                    <span className={cn(
                      "text-xs font-black shrink-0",
                      integration.score >= 90 ? "text-emerald-600" :
                      integration.score >= 70 ? "text-amber-600" :
                      "text-red-600"
                    )}>
                      {integration.score}%
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="hidden md:flex flex-col items-end gap-2 shrink-0 pt-0.5">
              {isConnected ? (
                <span className="inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-sm">
                  <CheckCircle2 className="w-3 h-3 ml-1" />
                  מחובר
                </span>
              ) : isConnecting ? (
                 <span className="inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 shadow-sm">
                  <Loader2 className="w-3 h-3 ml-1 animate-spin" />
                  מתחבר...
                </span>
              ) : hasError ? (
                <span className="inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold bg-red-50 text-red-700 border border-red-200 shadow-sm">
                  <AlertCircle className="w-3 h-3 ml-1" />
                  שגיאה
                </span>
              ) : (
                <span className="inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold bg-gray-100 text-gray-600 border border-gray-200">
                  לא מחובר
                </span>
              )}
            </div>
          </div>

          {!isExpanded && (
            <button
              onClick={() => handleExpand(integration)}
              disabled={isConnecting}
              className={cn(
                "mt-4 w-full inline-flex justify-center items-center px-3 py-2 border text-xs font-bold rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed",
                isConnected
                  ? "border-gray-200 text-gray-700 bg-white hover:bg-gray-50 hover:border-gray-300 shadow-sm"
                  : hasError
                  ? "border-transparent text-white bg-red-600 hover:bg-red-700 shadow-md hover:shadow-lg"
                  : "border-transparent text-white bg-indigo-600 hover:bg-indigo-700 shadow-md hover:shadow-lg"
              )}
            >
              {isConnecting ? (
                <><Loader2 className="w-3.5 h-3.5 ml-1.5 animate-spin" /> מתחבר...</>
              ) : isConnected ? (
                <><Settings2 className="w-3.5 h-3.5 ml-1.5" /> הגדרות חיבור</>
              ) : hasError ? (
                <><AlertCircle className="w-3.5 h-3.5 ml-1.5" /> נסה שוב</>
              ) : (
                <><Plug className="w-3.5 h-3.5 ml-1.5" /> התחבר לחשבון</>
              )}
            </button>
          )}

          <AnimatePresence>
            {isExpanded && renderIntegrationSettings(integration)}
          </AnimatePresence>
        </div>
      </motion.div>
    );
  };

  const aiConnections = connections.filter(c => c.category === 'AI Engine');
  const googleConnections = connections.filter(c => c.category === 'Google');
  const socialConnections = connections.filter(c => c.category === 'Social');
  const ecommerceConnections = connections.filter(c => c.category === 'E-commerce');

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      <div className="flex items-center justify-between bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
        <div>
          <h1 className="text-xl font-black text-gray-900">חיבורים ואינטגרציות</h1>
          <p className="text-sm text-gray-500 mt-1 font-medium">נהל את החיבורים לפלטפורמות הפרסום, האנליטיקה והחנות שלך בצורה מאובטחת.</p>
        </div>
        <div className="hidden sm:flex items-center justify-center w-10 h-10 bg-indigo-50 rounded-xl text-indigo-600">
          <Plug className="w-5 h-5" />
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-xl flex items-start justify-between shadow-sm animate-in fade-in">
          <div className="flex items-center">
            <AlertCircle className="h-5 w-5 text-red-500 ml-3" />
            <div>
              <h3 className="text-sm font-bold text-red-800">שגיאת התחברות ({connections.find(i => i.id === error.id)?.name})</h3>
              <p className="text-sm text-red-700 mt-1">{error.message}</p>
            </div>
          </div>
          <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700 p-1 hover:bg-red-100 rounded-lg transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="space-y-8">
        {aiConnections.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <h2 className="text-lg font-black text-gray-900">מנוע AI</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {aiConnections.map(renderConnectionCard)}
            </div>
          </section>
        )}

        {googleConnections.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                <Megaphone className="w-3.5 h-3.5" />
              </div>
              <h2 className="text-lg font-black text-gray-900">Google Workspace</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {googleConnections.map(renderConnectionCard)}
            </div>
          </section>
        )}

        {socialConnections.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-pink-100 text-pink-600 flex items-center justify-center">
                <Facebook className="w-3.5 h-3.5" />
              </div>
              <h2 className="text-lg font-black text-gray-900">רשתות חברתיות ופרסום</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {socialConnections.map(renderConnectionCard)}
            </div>
          </section>
        )}

        {ecommerceConnections.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <ShoppingCart className="w-3.5 h-3.5" />
              </div>
              <h2 className="text-lg font-black text-gray-900">מסחר אלקטרוני (E-commerce)</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {ecommerceConnections.map(renderConnectionCard)}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
